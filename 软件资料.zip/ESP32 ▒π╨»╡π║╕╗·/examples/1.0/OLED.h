#ifndef OLED_H
#define OLED_H
#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 display = Adafruit_SSD1306(128, 32, &Wire);        

//取16X16汉字字模 逐行式 顺向高位在前 C51 阴码

static const unsigned char PROGMEM zi[]   = {
0x01,0x00,0x02,0x00,0x04,0x00,0x1F,0xF0,0x10,0x10,0x10,0x10,0x10,0x10,0x1F,0xF0,
0x10,0x10,0x10,0x10,0x1F,0xF0,0x10,0x10,0x10,0x10,0x10,0x10,0x1F,0xF0,0x10,0x10};/*自*/
static const unsigned char PROGMEM shou[] = {
0x00,0x10,0x00,0xF8,0x3F,0x00,0x01,0x00,0x01,0x00,0x3F,0xF8,0x01,0x00,0x01,0x00,
0x01,0x00,0xFF,0xFE,0x01,0x00,0x01,0x00,0x01,0x00,0x01,0x00,0x05,0x00,0x02,0x00};/*手*/
static const unsigned char PROGMEM dong[] = {
0x00,0x40,0x00,0x40,0x7C,0x40,0x00,0x40,0x01,0xFC,0x00,0x44,0xFE,0x44,0x20,0x44,
0x20,0x44,0x20,0x84,0x48,0x84,0x44,0x84,0xFD,0x04,0x45,0x04,0x02,0x28,0x04,0x10};/*动*/

static const unsigned char PROGMEM mo[]   = {
0x11,0x10,0x11,0x10,0x17,0xFC,0x11,0x10,0xFC,0x00,0x13,0xF8,0x32,0x08,0x3B,0xF8,
0x56,0x08,0x53,0xF8,0x90,0x40,0x17,0xFC,0x10,0xA0,0x11,0x10,0x12,0x08,0x14,0x06};/*模*/
static const unsigned char PROGMEM shi[]  = {
0x00,0x48,0x00,0x44,0x00,0x44,0x00,0x40,0xFF,0xFE,0x00,0x40,0x00,0x40,0x3E,0x40,
0x08,0x40,0x08,0x40,0x08,0x20,0x08,0x22,0x0F,0x12,0x78,0x0A,0x20,0x06,0x00,0x02};/*式*/

static const unsigned char PROGMEM dian3[]  = {
0x02,0x00,0x02,0x00,0x02,0x00,0x03,0xFC,0x02,0x00,0x02,0x00,0x3F,0xF0,0x20,0x10,
0x20,0x10,0x20,0x10,0x3F,0xF0,0x00,0x00,0x24,0x88,0x22,0x44,0x42,0x44,0x80,0x04};/*点*/
static const unsigned char PROGMEM han[]  = {
0x10,0x00,0x11,0xFC,0x11,0x04,0x11,0xFC,0x55,0x04,0x59,0xFC,0x50,0x00,0x90,0x00,
0x11,0xFC,0x10,0x20,0x10,0x20,0x2B,0xFE,0x24,0x20,0x44,0x20,0x40,0x20,0x80,0x20};/*焊*/
static const unsigned char PROGMEM shi2[]  = {
0x00,0x08,0x00,0x08,0x7C,0x08,0x44,0x08,0x45,0xFE,0x44,0x08,0x44,0x08,0x7C,0x08,
0x44,0x88,0x44,0x48,0x44,0x48,0x44,0x08,0x7C,0x08,0x44,0x08,0x00,0x28,0x00,0x10};/*时*/
static const unsigned char PROGMEM jian[]  = {
0x20,0x00,0x13,0xFC,0x10,0x04,0x40,0x04,0x47,0xC4,0x44,0x44,0x44,0x44,0x44,0x44,
0x47,0xC4,0x44,0x44,0x44,0x44,0x44,0x44,0x47,0xC4,0x40,0x04,0x40,0x14,0x40,0x08};/*间*/

static const unsigned char PROGMEM she[] = {
0x00,0x00,0x21,0xF0,0x11,0x10,0x11,0x10,0x01,0x10,0x02,0x0E,0xF4,0x00,0x13,0xF8,
0x11,0x08,0x11,0x10,0x10,0x90,0x14,0xA0,0x18,0x40,0x10,0xA0,0x03,0x18,0x0C,0x06};/*设*/
static const unsigned char PROGMEM zhi[] = {
0x7F,0xFC,0x44,0x44,0x7F,0xFC,0x01,0x00,0x7F,0xFC,0x01,0x00,0x1F,0xF0,0x10,0x10,
0x1F,0xF0,0x10,0x10,0x1F,0xF0,0x10,0x10,0x1F,0xF0,0x10,0x10,0xFF,0xFE,0x00,0x00};/*置*/
static const unsigned char PROGMEM bao[] = {
0x08,0x00,0x0B,0xF8,0x0A,0x08,0x12,0x08,0x12,0x08,0x33,0xF8,0x30,0x40,0x50,0x40,
0x97,0xFC,0x10,0xE0,0x11,0x50,0x12,0x48,0x14,0x44,0x18,0x42,0x10,0x40,0x10,0x40};/*保*/
static const unsigned char PROGMEM cun[] = {
0x04,0x00,0x04,0x00,0xFF,0xFE,0x08,0x00,0x08,0x00,0x13,0xF8,0x10,0x10,0x30,0x20,
0x50,0x40,0x97,0xFE,0x10,0x40,0x10,0x40,0x10,0x40,0x10,0x40,0x11,0x40,0x10,0x80};/*存*/

static const unsigned char PROGMEM chong[] = {
0x02,0x00,0x01,0x00,0xFF,0xFE,0x04,0x00,0x04,0x00,0x08,0x20,0x10,0x10,0x3F,0xF8,
0x04,0x48,0x04,0x40,0x04,0x40,0x04,0x40,0x08,0x44,0x08,0x44,0x10,0x44,0x60,0x3C};/*充*/
static const unsigned char PROGMEM dian[] = {
0x01,0x00,0x01,0x00,0x01,0x00,0x3F,0xF8,0x21,0x08,0x21,0x08,0x21,0x08,0x3F,0xF8,
0x21,0x08,0x21,0x08,0x21,0x08,0x3F,0xF8,0x21,0x0A,0x01,0x02,0x01,0x02,0x00,0xFE};/*电*/

static const unsigned char PROGMEM ping[] = {
0x00,0x00,0x3F,0xF8,0x20,0x08,0x20,0x08,0x3F,0xF8,0x24,0x10,0x22,0x20,0x2F,0xF8,
0x22,0x20,0x22,0x20,0x3F,0xFC,0x22,0x20,0x42,0x20,0x44,0x20,0x84,0x20,0x08,0x20};/*屏*/
static const unsigned char PROGMEM xian[] = {
0x00,0x00,0x1F,0xF0,0x10,0x10,0x10,0x10,0x1F,0xF0,0x10,0x10,0x10,0x10,0x1F,0xF0,
0x04,0x40,0x44,0x44,0x24,0x44,0x14,0x48,0x14,0x50,0x04,0x40,0xFF,0xFE,0x00,0x00};/*显*/
static const unsigned char PROGMEM fang[] = {
0x02,0x00,0x01,0x00,0x01,0x00,0xFF,0xFE,0x04,0x00,0x04,0x00,0x04,0x00,0x07,0xF0,
0x04,0x10,0x04,0x10,0x04,0x10,0x08,0x10,0x08,0x10,0x10,0x10,0x20,0xA0,0x40,0x40};/*方*/
static const unsigned char PROGMEM xiang[] = {
0x02,0x00,0x04,0x00,0x08,0x00,0x7F,0xFC,0x40,0x04,0x40,0x04,0x47,0xC4,0x44,0x44,
0x44,0x44,0x44,0x44,0x44,0x44,0x47,0xC4,0x44,0x44,0x40,0x04,0x40,0x14,0x40,0x08};/*向*/


void csh(int xy){
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);   //初始化I2C地址0X3C
  if(xy == 0){
    display.setRotation(0); //设置屏幕方向 0/0°, 1/90° ,2/180°, 3/270°
  }else{
    display.setRotation(2); 
  }
}

//自动模式
void ms0(){
  display.clearDisplay();
  display.setTextColor(1);                
  display.setTextSize(2);                 
  display.drawBitmap( 32, 0,   zi, 16, 16,1);    
  display.drawBitmap( 48, 0, dong, 16, 16,1);
  display.drawBitmap( 64, 0,   mo, 16, 16,1);    
  display.drawBitmap( 80, 0,  shi, 16, 16,1);  
  display.display();                         
}

//手动模式
void ms1(){
  display.clearDisplay();
  display.setTextColor(1);                
  display.setTextSize(2);                 
  display.drawBitmap( 32, 0, shou, 16, 16,1);    
  display.drawBitmap( 48, 0, dong, 16, 16,1);
  display.drawBitmap( 64, 0,   mo, 16, 16,1);    
  display.drawBitmap( 80, 0,  shi, 16, 16,1);  
  display.display();                         
}

//点焊时间设置模式
void ms2(){
  display.clearDisplay();
  display.setTextColor(1);                   
  display.setTextSize(2);                 
  display.drawBitmap( 16, 0,dian3, 16, 16,1);    
  display.drawBitmap( 32, 0,  han, 16, 16,1);
  display.drawBitmap( 48, 0, shi2, 16, 16,1);    
  display.drawBitmap( 64, 0, jian, 16, 16,1); 
  display.drawBitmap( 80, 0,  she, 16, 16,1);    
  display.drawBitmap( 96, 0,  zhi, 16, 16,1); 
  display.display();                         
}

//充电模式
void ms3(float vba,float vcc){
  display.clearDisplay();
  display.setTextColor(1);                
  display.setTextSize(2);                 
  display.drawBitmap( 32, 0,chong, 16, 16,1);    
  display.drawBitmap( 48, 0, dian, 16, 16,1);
  display.drawBitmap( 64, 0,   mo, 16, 16,1);    
  display.drawBitmap( 80, 0,  shi, 16, 16,1);
  
  display.setTextSize(1);
  display.setCursor(  0, 25);   display.print("Li:");
  display.setCursor( 25, 25);   display.print(vba); 
  display.setCursor( 50, 25);   display.print("V");

  display.setCursor( 70, 25);   display.print("Ci:");
  display.setCursor( 90, 25);   display.print(vcc);
  display.setCursor(122, 25);   display.print("V"); 
  display.display();                         
}

//LED开关设置模式
void ms4(int a){
  display.clearDisplay();
  display.setTextColor(1);                   
  display.setTextSize(3); 
  display.setCursor( 0 , 0 );  display.print("LED:");
  display.setCursor(110, 0 );  display.print(a);
  display.display();                                          
}

//屏显方向设置模式
void ms5(int a){
  if(a == 0){ display.setRotation(0); }else{ display.setRotation(2); }
  display.clearDisplay();
  display.setTextColor(1);                  
  display.setTextSize(2);                 
  display.drawBitmap( 32, 0, ping, 16, 16,1);    
  display.drawBitmap( 48, 0, xian, 16, 16,1);
  display.drawBitmap( 64, 0, fang, 16, 16,1);    
  display.drawBitmap( 80, 0, xiang, 16, 16,1);
  display.setCursor( 60, 17);   display.print(a);
  display.display();                     
}

//设置保存
void ms6(int a){
  display.clearDisplay();
  display.setTextColor(1);                   
  display.setTextSize(2);                 
  display.drawBitmap( 32, 0,  she, 16, 16,1);    
  display.drawBitmap( 48, 0,  zhi, 16, 16,1);
  display.drawBitmap( 64, 0,  bao, 16, 16,1);    
  display.drawBitmap( 80, 0,  cun, 16, 16,1); 
  display.setCursor( 60, 17);   display.print(a);
  display.display();                         
}

//自动模式页面
void ym0(float vba, float vcc, float vhj, float i){
  int w = int(i);
  w = map( w, 0, 100, 0, 114 );

  display.clearDisplay(); 
          
  if(vhj > 0.2){  display.fillRect( 0, 0, 2, 16, WHITE);}
  display.fillTriangle(2, 8, 10, 0, 10, 16, WHITE);  //实心三角形(x0,y0,x1,y1,x2,y2,rgb)
  display.drawRect( 10, 0 ,116, 17, WHITE);          //空心矩形(x,y,w,h,rgb)
  display.fillRect( 12, 2 , w , 13, WHITE);          //实心矩形(x,y,w,h,rgb)


  display.setTextSize(1);
  display.setCursor(  0, 25);   display.print("Li:");
  display.setCursor( 22, 25);   display.print(vba); 
  display.setCursor( 50, 25);   display.print("V");

  display.setCursor( 70, 25);   display.print("Ci:");
  display.setCursor( 90, 25);   display.print(vcc);
  display.setCursor(122, 25);   display.print("V");
 
  display.display();                         
}

//手动模式页面
void ym1(float vba, float vcc, float vhj, float MS, float a){
  int k = int(a);
  if(k == 0){ k = 10; }else{ k = 20; }
  
  display.clearDisplay(); 
  display.setTextColor(1);
  display.setTextSize(1);
  
  display.setCursor( 8, 7);            
  if(vhj > 0.3){ 
    display.print("ON");
    display.drawLine( 1 , 0, 1, 20, WHITE); 
  }else{
    display.print("OFF");
  }

  display.drawLine( 2 , 8 , 10, 0 , WHITE);   //画线(x0,y0,x1,y1)
  display.drawLine( 2 , 12, 10, 20, WHITE);

  display.drawLine( 10, 0 ,120, 0 , WHITE);
  
  display.drawLine( 10, 20, 60, 20, WHITE);
  display.drawLine( 60, 20, 70, k , WHITE);   //开关
  display.drawLine( 70, 20,120, 20, WHITE);
  
  display.drawFastHLine( 10, 20, 50, WHITE);  //画横线（x,y,w,rgb）
  display.drawFastHLine( 70, 20, 50, WHITE);

  display.drawFastHLine(112, 8 , 16, WHITE);
  display.drawFastHLine(112, 12, 16, WHITE);
    
  display.drawFastVLine( 120, 0 , 8, WHITE);  //画竖线（x,y,h,rgb）
  display.drawFastVLine( 120, 12, 8, WHITE);  //画竖线（x,y,h,rgb）

  display.setCursor( 80, 7);    display.print("MS:");  display.print(int(MS));
  
  display.setCursor(  0, 25);   display.print("Li:");
  display.setCursor( 22, 25);   display.print(vba); 
  display.setCursor( 50, 25);   display.print("V");

  display.setCursor( 70, 25);   display.print("Ci:");
  display.setCursor( 90, 25);   display.print(vcc);
  display.setCursor(122, 25);   display.print("V");
 
  display.display();                         
}


//点焊时间设置
void ym2(int tl1, int th1, int tl2, int th2, int i){
  int x = 0;
  if(i == 1){       
  }else if(i == 2){ x = 33; 
  }else if(i == 3){ x = 63; 
  }else if(i == 4){ x = 93; 
  }

  display.clearDisplay();
  display.setTextColor(1);                   
  display.setTextSize(1); 

  display.setCursor( 0 , 0 );  display.print("TL1");
  display.setCursor( 0 , 18);  display.print(tl1);

  display.setCursor( 33, 0 );  display.print("TH1");
  display.setCursor( 33, 18);  display.print(th1);

  display.setCursor( 63, 0 );  display.print("TL2");
  display.setCursor( 63, 18);  display.print(tl2);
  
  display.setCursor( 93, 0 );  display.print("TH2");
  display.setCursor( 93, 18);  display.print(th2);

  display.drawFastHLine( x , 9 , 18, WHITE);

  display.drawFastHLine( 0 , 31, 30, WHITE);  //画横线（x,y,w,rgb）
  display.drawFastVLine( 30, 12, 20, WHITE);  //画竖线（x,y,h,rgb）

  display.drawFastHLine( 30, 12, 30, WHITE);  
  display.drawFastVLine( 60, 12, 20, WHITE);

  display.drawFastHLine( 60, 31, 30, WHITE);
  display.drawFastVLine( 90, 12, 20, WHITE);  

  display.drawFastHLine( 90, 12, 30, WHITE);
  display.drawFastVLine(120, 12, 20, WHITE); 

  display.drawFastHLine(120, 31,  8, WHITE);
  
  display.display();                     
}

//电量显示模式
void ym3(float vin, float vba, float vcc){
  int x = 12;
  int x1 = 14;
  int w = 90;
  int a = int(vin*100);
  a = map( a, 0, 505, 0, w-2);
  
  int b = int(vba*100);
  b = map( b, 0, 425, 0, w-2);
  
  int c = int(vcc*100);
  c = map( c, 0, 275, 0, w-2);

  display.clearDisplay();            
  display.setTextColor(1);   
  display.setCursor( 0 , 0 );   display.print("Vi");
  display.setCursor(104, 0 );   display.print("5.0V");
                 
  display.setCursor( 0 , 11);   display.print("Li");
  display.setCursor(104, 11);   display.print("4.2V");
  
  display.setCursor( 0 , 24);   display.print("Ci");
  display.setCursor(104, 22);   display.print("2.7V");

  display.drawRect( x , 0 , w , 8 , WHITE);   //画空心矩形(x,y,w,h,rgb)
  display.fillRect( x1, 2 , a , 4 , WHITE);   //画实心矩形(x,y,w,h,rgb)
  
  display.drawRect( x , 11, w , 8 , WHITE);
  display.fillRect( x1, 13, b , 4 , WHITE);
  
  display.drawRect( x , 22, w , 8 , WHITE);
  display.fillRect( x1, 24, c , 4 , WHITE); 

  display.display();                         
}

//充电设置模式
void ym4(float vin, float vba, float vcc, float ven){
  int y1 = 1;
  int y2 = 21;
  if(int(ven) == 1){ y1 = 6; 
  }else if(int(ven) == 2) { y2 = 26;  
  }

  display.clearDisplay();            
  display.setTextColor(1);   
  display.setCursor( 2 , 2 );   display.print("Vi:"); display.print(vin);
                 
  display.setCursor( 2 , 22);   display.print("Li:"); display.print(vba);
  
  display.setCursor(102, 2 );   display.print("Ci:");
  display.setCursor(102, 22);   display.print(vcc);
  
  display.drawRect( 0 , 0 , 45, 12, WHITE);  //空心矩形(x,y,w,h,rgb)
  display.drawRect( 0 , 20, 45, 12, WHITE);
  display.drawRect(100, 0 , 28, 32, WHITE);

  display.drawLine( 45, 6 , 70, 6 , WHITE);  //画线(x0,y0,x1,y1)
  display.drawLine( 70, 6 , 75, y1, WHITE);  //开关
  display.drawLine( 75, 6 ,100, 6 , WHITE);

  display.drawLine( 45, 26, 70, 26, WHITE);  //画线(x0,y0,x1,y1)
  display.drawLine( 70, 26, 75, y2, WHITE);  //开关
  display.drawLine( 75, 26,100, 26, WHITE);

  display.display();                         
}

#endif
